/* -*- mode:::: js2; js2-basic-offset: 4; indent-tabs-mode: nil -*- */

/*
 * Simple extension to lock the screen from an icon on the panel.
 * The plan is to integrate this function into the GNOME User Menu
 * as close to the default GNOME function as possible (Lock Button Look & Position)
 */

const Gio = imports.gi.Gio;
const Lang = imports.lang;
const Shell = imports.gi.Shell;
const St = imports.gi.St;
const Util = imports.misc.util;
const Main = imports.ui.main;
const BoxPointer = imports.ui.boxpointer;
const Config = imports.misc.config;

let _lockScreenButton = null;

/* 

	Suspendcode added by M.Schwarz http://marius.bloggt-in-braunschweig.de  

	Suspendcode came from Raphael Freudiger <laser_b@gmx.ch>

*/

function init() {

	_lockScreenButton = new St.Bin({ style_class: 'panel-button', 
								reactive: true,
								can_focus: true,
								track_hover: true });
	let icon = new St.Icon ({ icon_name: 'changes-prevent-symbolic',
								style_class: 'system-status-icon'});
								
	_lockScreenButton.set_child(icon);
	_lockScreenButton.connect('button-press-event', _LockScreenActivate);
}

function _LockScreenActivate () {
	Util.spawn(['/usr/bin/dm-tool', 'lock']);
	let systemMenu = Main.panel.statusArea['aggregateMenu']._system;
	gnomeShellVersion = Config.PACKAGE_VERSION.split(".")
        if (systemMenu.hasOwnProperty('_systemActions')) {
            systemMenu.menu.itemActivated(BoxPointer.PopupAnimation.NONE);
            systemMenu._systemActions.activateSuspend()
        } else {
            systemMenu._onSuspendClicked()
        }
}


function enable () {
	Main.panel._rightBox.insert_child_at_index(_lockScreenButton,0);
}

function disable () {
	Main.panel._rightBox.remove_actor(_lockScreenButton);
}
